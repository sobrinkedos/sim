# Simulador Financeiro Empresarial

Simulador completo para operações de crédito empresarial com:

## Funcionalidades

- ✅ Cálculo de ECG (Encargo de Captação de Garantia)
- ✅ Cálculo de IOF (Imposto sobre Operações Financeiras)
- ✅ Cálculo de TAC (Tarifa de Abertura de Crédito)
- ✅ Seguro de Crédito Protegido
- ✅ Controle dinâmico para incluir/excluir seguro
- ✅ Cronograma com carência e amortização
- ✅ Exportação em formato .txt
- ✅ Interface responsiva e moderna

## Características do Seguro

- Primeira parcela paga no ato da contratação
- Última parcela paga na penúltima parcela do financiamento
- Cálculo baseado em tabela oficial por prazo em dias
- Multiplicador por quantidade de sócios

## Como usar

1. Preencha os dados da empresa
2. Configure os parâmetros financeiros
3. Defina se deseja incluir seguro no cronograma
4. Clique em "Calcular Simulação"
5. Visualize o cronograma e exporte se necessário

## Deploy

Este projeto está configurado para deploy automático na Vercel.

## Tecnologias

- HTML5
- CSS3
- JavaScript (Vanilla)
- Responsivo (Mobile-first)